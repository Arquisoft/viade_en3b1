var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "4840",
        "ok": "4706",
        "ko": "134"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "36150",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "2568",
        "ok": "932",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "10131",
        "ok": "2994",
        "ko": "1"
    },
    "percentiles1": {
        "total": "100",
        "ok": "89",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "778",
        "ok": "503",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "14748",
        "ok": "3041",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "14861",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3631,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 263,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 812,
    "percentage": 17
},
    "group4": {
    "name": "failed",
    "count": 134,
    "percentage": 3
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.268",
        "ok": "14.845",
        "ko": "0.423"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "88",
        "ok": "88",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "416",
        "ok": "416",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "percentiles1": {
        "total": "262",
        "ok": "262",
        "ko": "-"
    },
    "percentiles2": {
        "total": "287",
        "ok": "287",
        "ko": "-"
    },
    "percentiles3": {
        "total": "346",
        "ok": "346",
        "ko": "-"
    },
    "percentiles4": {
        "total": "384",
        "ok": "384",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_leaflet-css-a4c98": {
        type: "REQUEST",
        name: "leaflet.css",
path: "leaflet.css",
pathFormatted: "req_leaflet-css-a4c98",
stats: {
    "name": "leaflet.css",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "98",
        "ok": "98",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "224",
        "ok": "224",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "percentiles1": {
        "total": "232",
        "ok": "232",
        "ko": "-"
    },
    "percentiles2": {
        "total": "255",
        "ok": "255",
        "ko": "-"
    },
    "percentiles3": {
        "total": "282",
        "ok": "282",
        "ko": "-"
    },
    "percentiles4": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_favicon-ico-8af3a": {
        type: "REQUEST",
        name: "favicon.ico",
path: "favicon.ico",
pathFormatted: "req_favicon-ico-8af3a",
stats: {
    "name": "favicon.ico",
    "numberOfRequests": {
        "total": "260",
        "ok": "260",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1848",
        "ok": "1848",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "595",
        "ok": "595",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "751",
        "ok": "751",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1555",
        "ok": "1555",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1606",
        "ok": "1606",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1802",
        "ok": "1802",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 160,
    "percentage": 62
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 94,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.82",
        "ok": "0.82",
        "ko": "-"
    }
}
    },"req_bundle-js-0b837": {
        type: "REQUEST",
        name: "bundle.js",
path: "bundle.js",
pathFormatted: "req_bundle-js-0b837",
stats: {
    "name": "bundle.js",
    "numberOfRequests": {
        "total": "260",
        "ok": "260",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2494",
        "ok": "2494",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "644",
        "ok": "644",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "884",
        "ok": "884",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1400",
        "ok": "1400",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2378",
        "ok": "2378",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2468",
        "ok": "2468",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 165,
    "percentage": 63
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 24,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 71,
    "percentage": 27
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.82",
        "ok": "0.82",
        "ko": "-"
    }
}
    },"req_0-chunk-js-ddd34": {
        type: "REQUEST",
        name: "0.chunk.js",
path: "0.chunk.js",
pathFormatted: "req_0-chunk-js-ddd34",
stats: {
    "name": "0.chunk.js",
    "numberOfRequests": {
        "total": "260",
        "ok": "260",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "14941",
        "ok": "14941",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5713",
        "ok": "5713",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7192",
        "ok": "7192",
        "ko": "-"
    },
    "percentiles1": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14788",
        "ok": "14788",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14874",
        "ok": "14874",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14903",
        "ok": "14903",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 160,
    "percentage": 62
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 100,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.82",
        "ok": "0.82",
        "ko": "-"
    }
}
    },"req_main-chunk-js-7361f": {
        type: "REQUEST",
        name: "main.chunk.js",
path: "main.chunk.js",
pathFormatted: "req_main-chunk-js-7361f",
stats: {
    "name": "main.chunk.js",
    "numberOfRequests": {
        "total": "260",
        "ok": "260",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2630",
        "ok": "2630",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "816",
        "ok": "816",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1031",
        "ok": "1031",
        "ko": "-"
    },
    "percentiles1": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1849",
        "ok": "1849",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2528",
        "ok": "2528",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2601",
        "ok": "2601",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 160,
    "percentage": 62
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 98,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.82",
        "ok": "0.82",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "94",
        "ok": "94",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles1": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles2": {
        "total": "65",
        "ok": "65",
        "ko": "-"
    },
    "percentiles3": {
        "total": "76",
        "ok": "76",
        "ko": "-"
    },
    "percentiles4": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "percentiles1": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "percentiles2": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles3": {
        "total": "121",
        "ok": "121",
        "ko": "-"
    },
    "percentiles4": {
        "total": "122",
        "ok": "122",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "85",
        "ok": "85",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "percentiles2": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "percentiles3": {
        "total": "64",
        "ok": "64",
        "ko": "-"
    },
    "percentiles4": {
        "total": "85",
        "ok": "85",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "percentiles1": {
        "total": "81",
        "ok": "81",
        "ko": "-"
    },
    "percentiles2": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "percentiles3": {
        "total": "148",
        "ok": "148",
        "ko": "-"
    },
    "percentiles4": {
        "total": "156",
        "ok": "156",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "percentiles1": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "percentiles2": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles3": {
        "total": "121",
        "ok": "121",
        "ko": "-"
    },
    "percentiles4": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles3": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "689",
        "ok": "689",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "percentiles1": {
        "total": "435",
        "ok": "435",
        "ko": "-"
    },
    "percentiles2": {
        "total": "504",
        "ok": "504",
        "ko": "-"
    },
    "percentiles3": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "percentiles4": {
        "total": "597",
        "ok": "597",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "369",
        "ok": "369",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "87",
        "ok": "87",
        "ko": "-"
    },
    "percentiles1": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "percentiles2": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "percentiles3": {
        "total": "307",
        "ok": "307",
        "ko": "-"
    },
    "percentiles4": {
        "total": "310",
        "ok": "310",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "186",
        "ok": "186",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2340",
        "ok": "2340",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "909",
        "ok": "909",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "437",
        "ok": "437",
        "ko": "-"
    },
    "percentiles1": {
        "total": "979",
        "ok": "979",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1003",
        "ok": "1003",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2323",
        "ok": "2323",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2338",
        "ok": "2338",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 29
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 65,
    "percentage": 65
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "197",
        "ok": "197",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2352",
        "ok": "2352",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "943",
        "ok": "943",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "474",
        "ok": "474",
        "ko": "-"
    },
    "percentiles1": {
        "total": "980",
        "ok": "980",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1006",
        "ok": "1006",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2325",
        "ok": "2325",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2352",
        "ok": "2352",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 30,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 62,
    "percentage": 62
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3192",
        "ok": "3192",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1422",
        "ok": "1422",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "579",
        "ok": "579",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1350",
        "ok": "1350",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1599",
        "ok": "1599",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2865",
        "ok": "2865",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3162",
        "ok": "3162",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 12,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 13
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 75,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "326",
        "ok": "326",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2655",
        "ok": "2655",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1326",
        "ok": "1326",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "421",
        "ok": "421",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1260",
        "ok": "1260",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1613",
        "ok": "1613",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1951",
        "ok": "1951",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2634",
        "ok": "2634",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 21,
    "percentage": 11
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 39,
    "percentage": 20
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 140,
    "percentage": 70
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.631",
        "ok": "0.631",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "100",
        "ok": "40",
        "ko": "60"
    },
    "minResponseTime": {
        "total": "3527",
        "ok": "3527",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "36150",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "40640",
        "ok": "11599",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "24428",
        "ok": "9282",
        "ko": "1"
    },
    "percentiles1": {
        "total": "60000",
        "ok": "7440",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "60001",
        "ok": "11965",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "35479",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "36056",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 40,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 60,
    "percentage": 60
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.126",
        "ko": "0.189"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "84",
        "ok": "84",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4334",
        "ok": "4334",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1847",
        "ok": "1847",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1769",
        "ok": "1769",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1654",
        "ok": "1654",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4258",
        "ok": "4258",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4278",
        "ok": "4278",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4334",
        "ok": "4334",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 47,
    "percentage": 47
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 53,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-16-redi-ca4a2": {
        type: "REQUEST",
        name: "request_16 Redirect 1",
path: "request_16 Redirect 1",
pathFormatted: "req_request-16-redi-ca4a2",
stats: {
    "name": "request_16 Redirect 1",
    "numberOfRequests": {
        "total": "100",
        "ok": "60",
        "ko": "40"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "33820",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "26057",
        "ok": "3427",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "28206",
        "ok": "6766",
        "ko": "1"
    },
    "percentiles1": {
        "total": "6114",
        "ok": "386",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "60000",
        "ok": "3172",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "16498",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "32189",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 31,
    "percentage": 31
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 21,
    "percentage": 21
},
    "group4": {
    "name": "failed",
    "count": 40,
    "percentage": 40
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.189",
        "ko": "0.126"
    }
}
    },"req_request-16-redi-74dda": {
        type: "REQUEST",
        name: "request_16 Redirect 2",
path: "request_16 Redirect 2",
pathFormatted: "req_request-16-redi-74dda",
stats: {
    "name": "request_16 Redirect 2",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3035",
        "ok": "3035",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "542",
        "ok": "542",
        "ko": "-"
    },
    "percentiles1": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "percentiles2": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "percentiles3": {
        "total": "370",
        "ok": "370",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2795",
        "ok": "2795",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 57,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.189",
        "ok": "0.189",
        "ko": "-"
    }
}
    },"req_request-16-redi-6b920": {
        type: "REQUEST",
        name: "request_16 Redirect 3",
path: "request_16 Redirect 3",
pathFormatted: "req_request-16-redi-6b920",
stats: {
    "name": "request_16 Redirect 3",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.189",
        "ok": "0.189",
        "ko": "-"
    }
}
    },"req_request-19-10d85": {
        type: "REQUEST",
        name: "request_19",
path: "request_19",
pathFormatted: "req_request-19-10d85",
stats: {
    "name": "request_19",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2713",
        "ok": "2713",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "483",
        "ok": "483",
        "ko": "-"
    },
    "percentiles1": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "percentiles2": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1227",
        "ok": "1227",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1851",
        "ok": "1851",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 51,
    "percentage": 85
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.189",
        "ok": "0.189",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles2": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles3": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "percentiles4": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.189",
        "ok": "0.189",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles2": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "percentiles3": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "percentiles4": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.189",
        "ok": "0.189",
        "ko": "-"
    }
}
    },"req_request-20-6804b": {
        type: "REQUEST",
        name: "request_20",
path: "request_20",
pathFormatted: "req_request-20-6804b",
stats: {
    "name": "request_20",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1086",
        "ok": "1086",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "409",
        "ok": "409",
        "ko": "-"
    },
    "percentiles1": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1060",
        "ok": "1060",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1071",
        "ok": "1071",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1085",
        "ok": "1085",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 74,
    "percentage": 74
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 26,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-22-8ecb1": {
        type: "REQUEST",
        name: "request_22",
path: "request_22",
pathFormatted: "req_request-22-8ecb1",
stats: {
    "name": "request_22",
    "numberOfRequests": {
        "total": "100",
        "ok": "86",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "75",
        "ok": "75",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "32859",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "10853",
        "ok": "2852",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "20773",
        "ok": "6672",
        "ko": "0"
    },
    "percentiles1": {
        "total": "285",
        "ok": "229",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "5680",
        "ok": "1822",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "16653",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "32857",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 57,
    "percentage": 57
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 26,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "count": 14,
    "percentage": 14
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.271",
        "ko": "0.044"
    }
}
    },"req_request-21-be4cb": {
        type: "REQUEST",
        name: "request_21",
path: "request_21",
pathFormatted: "req_request-21-be4cb",
stats: {
    "name": "request_21",
    "numberOfRequests": {
        "total": "100",
        "ok": "89",
        "ko": "11"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "32543",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "8842",
        "ok": "2519",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "18755",
        "ok": "5637",
        "ko": "0"
    },
    "percentiles1": {
        "total": "847",
        "ok": "238",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "3994",
        "ok": "1867",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "13165",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "32349",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 50,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 36,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "count": 11,
    "percentage": 11
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.281",
        "ko": "0.035"
    }
}
    },"req_request-23-98f5d": {
        type: "REQUEST",
        name: "request_23",
path: "request_23",
pathFormatted: "req_request-23-98f5d",
stats: {
    "name": "request_23",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "193",
        "ok": "193",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "percentiles1": {
        "total": "95",
        "ok": "95",
        "ko": "-"
    },
    "percentiles2": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles3": {
        "total": "696",
        "ok": "696",
        "ko": "-"
    },
    "percentiles4": {
        "total": "724",
        "ok": "724",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-24-dd0c9": {
        type: "REQUEST",
        name: "request_24",
path: "request_24",
pathFormatted: "req_request-24-dd0c9",
stats: {
    "name": "request_24",
    "numberOfRequests": {
        "total": "100",
        "ok": "91",
        "ko": "9"
    },
    "minResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "31704",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "6151",
        "ok": "825",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "17307",
        "ok": "3741",
        "ko": "1"
    },
    "percentiles1": {
        "total": "97",
        "ok": "90",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "202",
        "ok": "141",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "1690",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "17305",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 83,
    "percentage": 83
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "count": 9,
    "percentage": 9
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.287",
        "ko": "0.028"
    }
}
    },"req_request-25-20ee6": {
        type: "REQUEST",
        name: "request_25",
path: "request_25",
pathFormatted: "req_request-25-20ee6",
stats: {
    "name": "request_25",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-26-18b3c": {
        type: "REQUEST",
        name: "request_26",
path: "request_26",
pathFormatted: "req_request-26-18b3c",
stats: {
    "name": "request_26",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "115",
        "ok": "115",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles4": {
        "total": "114",
        "ok": "114",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-27-649b0": {
        type: "REQUEST",
        name: "request_27",
path: "request_27",
pathFormatted: "req_request-27-649b0",
stats: {
    "name": "request_27",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "112",
        "ok": "112",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles1": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles2": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "percentiles3": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles4": {
        "total": "112",
        "ok": "112",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-28-297b8": {
        type: "REQUEST",
        name: "request_28",
path: "request_28",
pathFormatted: "req_request-28-297b8",
stats: {
    "name": "request_28",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1613",
        "ok": "1613",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "214",
        "ok": "214",
        "ko": "-"
    },
    "percentiles1": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "percentiles2": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "percentiles3": {
        "total": "95",
        "ok": "95",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1484",
        "ok": "1484",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 98,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-29-6a22e": {
        type: "REQUEST",
        name: "request_29",
path: "request_29",
pathFormatted: "req_request-29-6a22e",
stats: {
    "name": "request_29",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7144",
        "ok": "7144",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "341",
        "ok": "341",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1078",
        "ok": "1078",
        "ko": "-"
    },
    "percentiles1": {
        "total": "83",
        "ok": "83",
        "ko": "-"
    },
    "percentiles2": {
        "total": "146",
        "ok": "146",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1139",
        "ok": "1139",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7134",
        "ok": "7134",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 92,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-30-b7b42": {
        type: "REQUEST",
        name: "request_30",
path: "request_30",
pathFormatted: "req_request-30-b7b42",
stats: {
    "name": "request_30",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "878",
        "ok": "878",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "117",
        "ok": "117",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles1": {
        "total": "95",
        "ok": "95",
        "ko": "-"
    },
    "percentiles2": {
        "total": "118",
        "ok": "118",
        "ko": "-"
    },
    "percentiles3": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "percentiles4": {
        "total": "627",
        "ok": "627",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 99,
    "percentage": 99
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-32-84a21": {
        type: "REQUEST",
        name: "request_32",
path: "request_32",
pathFormatted: "req_request-32-84a21",
stats: {
    "name": "request_32",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1363",
        "ok": "1363",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "268",
        "ok": "268",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "percentiles1": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles2": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1242",
        "ok": "1242",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1356",
        "ok": "1356",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 93,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 7,
    "percentage": 7
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-31-261d3": {
        type: "REQUEST",
        name: "request_31",
path: "request_31",
pathFormatted: "req_request-31-261d3",
stats: {
    "name": "request_31",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3359",
        "ok": "3359",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "454",
        "ok": "454",
        "ko": "-"
    },
    "percentiles1": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles2": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1249",
        "ok": "1249",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1561",
        "ok": "1561",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 89,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-33-6bb92": {
        type: "REQUEST",
        name: "request_33",
path: "request_33",
pathFormatted: "req_request-33-6bb92",
stats: {
    "name": "request_33",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "percentiles1": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles3": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "percentiles4": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 100,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    },"req_request-34-d9757": {
        type: "REQUEST",
        name: "request_34",
path: "request_34",
pathFormatted: "req_request-34-d9757",
stats: {
    "name": "request_34",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1358",
        "ok": "1358",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "percentiles1": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "percentiles2": {
        "total": "244",
        "ok": "244",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1226",
        "ok": "1226",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1355",
        "ok": "1355",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 93,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 7,
    "percentage": 7
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.315",
        "ok": "0.315",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
