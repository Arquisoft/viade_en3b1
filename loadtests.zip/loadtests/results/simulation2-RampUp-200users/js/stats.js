var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "10265",
        "ok": "10234",
        "ko": "31"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "34634",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "757",
        "ok": "578",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "4121",
        "ok": "2523",
        "ko": "1"
    },
    "percentiles1": {
        "total": "25",
        "ok": "25",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "368",
        "ok": "362",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "2323",
        "ok": "2251",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "16045",
        "ok": "8450",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9010,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 264,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 960,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "count": 31,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.713",
        "ok": "56.541",
        "ko": "0.171"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_leaflet-css-a4c98": {
        type: "REQUEST",
        name: "leaflet.css",
path: "leaflet.css",
pathFormatted: "req_leaflet-css-a4c98",
stats: {
    "name": "leaflet.css",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "51",
        "ok": "51",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "166",
        "ok": "166",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "65",
        "ok": "65",
        "ko": "-"
    },
    "percentiles2": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles3": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "percentiles4": {
        "total": "116",
        "ok": "116",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_favicon-ico-8af3a": {
        type: "REQUEST",
        name: "favicon.ico",
path: "favicon.ico",
pathFormatted: "req_favicon-ico-8af3a",
stats: {
    "name": "favicon.ico",
    "numberOfRequests": {
        "total": "585",
        "ok": "585",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "50",
        "ok": "50",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles4": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 585,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.232",
        "ok": "3.232",
        "ko": "-"
    }
}
    },"req_bundle-js-0b837": {
        type: "REQUEST",
        name: "bundle.js",
path: "bundle.js",
pathFormatted: "req_bundle-js-0b837",
stats: {
    "name": "bundle.js",
    "numberOfRequests": {
        "total": "585",
        "ok": "585",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "46",
        "ok": "46",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "percentiles4": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 585,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.232",
        "ok": "3.232",
        "ko": "-"
    }
}
    },"req_0-chunk-js-ddd34": {
        type: "REQUEST",
        name: "0.chunk.js",
path: "0.chunk.js",
pathFormatted: "req_0-chunk-js-ddd34",
stats: {
    "name": "0.chunk.js",
    "numberOfRequests": {
        "total": "585",
        "ok": "585",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "634",
        "ok": "634",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "237",
        "ok": "237",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles2": {
        "total": "485",
        "ok": "485",
        "ko": "-"
    },
    "percentiles3": {
        "total": "563",
        "ok": "563",
        "ko": "-"
    },
    "percentiles4": {
        "total": "592",
        "ok": "592",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 585,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.232",
        "ok": "3.232",
        "ko": "-"
    }
}
    },"req_main-chunk-js-7361f": {
        type: "REQUEST",
        name: "main.chunk.js",
path: "main.chunk.js",
pathFormatted: "req_main-chunk-js-7361f",
stats: {
    "name": "main.chunk.js",
    "numberOfRequests": {
        "total": "585",
        "ok": "585",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "68",
        "ok": "68",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25",
        "ok": "25",
        "ko": "-"
    },
    "percentiles3": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "percentiles4": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 585,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.232",
        "ok": "3.232",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles4": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "716",
        "ok": "716",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "164",
        "ok": "164",
        "ko": "-"
    },
    "percentiles1": {
        "total": "254",
        "ok": "254",
        "ko": "-"
    },
    "percentiles2": {
        "total": "379",
        "ok": "379",
        "ko": "-"
    },
    "percentiles3": {
        "total": "502",
        "ok": "502",
        "ko": "-"
    },
    "percentiles4": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "632",
        "ok": "632",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "277",
        "ok": "277",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "167",
        "ok": "167",
        "ko": "-"
    },
    "percentiles1": {
        "total": "299",
        "ok": "299",
        "ko": "-"
    },
    "percentiles2": {
        "total": "401",
        "ok": "401",
        "ko": "-"
    },
    "percentiles3": {
        "total": "527",
        "ok": "527",
        "ko": "-"
    },
    "percentiles4": {
        "total": "600",
        "ok": "600",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "400",
        "ok": "400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "878",
        "ok": "878",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "369",
        "ok": "369",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "234",
        "ok": "234",
        "ko": "-"
    },
    "percentiles1": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles2": {
        "total": "549",
        "ok": "549",
        "ko": "-"
    },
    "percentiles3": {
        "total": "744",
        "ok": "744",
        "ko": "-"
    },
    "percentiles4": {
        "total": "843",
        "ok": "843",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 390,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.21",
        "ok": "2.21",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "294",
        "ok": "294",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "89",
        "ok": "89",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles1": {
        "total": "78",
        "ok": "78",
        "ko": "-"
    },
    "percentiles2": {
        "total": "143",
        "ok": "143",
        "ko": "-"
    },
    "percentiles3": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "percentiles4": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "631",
        "ok": "631",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "281",
        "ok": "281",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "167",
        "ok": "167",
        "ko": "-"
    },
    "percentiles1": {
        "total": "302",
        "ok": "302",
        "ko": "-"
    },
    "percentiles2": {
        "total": "404",
        "ok": "404",
        "ko": "-"
    },
    "percentiles3": {
        "total": "530",
        "ok": "530",
        "ko": "-"
    },
    "percentiles4": {
        "total": "598",
        "ok": "598",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "970",
        "ok": "970",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "425",
        "ok": "425",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "256",
        "ok": "256",
        "ko": "-"
    },
    "percentiles1": {
        "total": "460",
        "ok": "460",
        "ko": "-"
    },
    "percentiles2": {
        "total": "615",
        "ok": "615",
        "ko": "-"
    },
    "percentiles3": {
        "total": "791",
        "ok": "791",
        "ko": "-"
    },
    "percentiles4": {
        "total": "905",
        "ok": "905",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 190,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17741",
        "ok": "17741",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1629",
        "ok": "1629",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1772",
        "ok": "1772",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1470",
        "ok": "1470",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2166",
        "ok": "2166",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3629",
        "ok": "3629",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9362",
        "ok": "9362",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 24,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 116,
    "percentage": 58
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "85",
        "ok": "85",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "920",
        "ok": "920",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "448",
        "ok": "448",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles1": {
        "total": "453",
        "ok": "453",
        "ko": "-"
    },
    "percentiles2": {
        "total": "583",
        "ok": "583",
        "ko": "-"
    },
    "percentiles3": {
        "total": "757",
        "ok": "757",
        "ko": "-"
    },
    "percentiles4": {
        "total": "872",
        "ok": "872",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 195,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-16-redi-ca4a2": {
        type: "REQUEST",
        name: "request_16 Redirect 1",
path: "request_16 Redirect 1",
pathFormatted: "req_request-16-redi-ca4a2",
stats: {
    "name": "request_16 Redirect 1",
    "numberOfRequests": {
        "total": "200",
        "ok": "185",
        "ko": "15"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "32568",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "10093",
        "ok": "6046",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "17369",
        "ok": "10384",
        "ko": "0"
    },
    "percentiles1": {
        "total": "760",
        "ok": "678",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "8082",
        "ok": "7401",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "32093",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "32271",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 101,
    "percentage": 51
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 78,
    "percentage": 39
},
    "group4": {
    "name": "failed",
    "count": 15,
    "percentage": 8
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.022",
        "ko": "0.083"
    }
}
    },"req_request-16-redi-74dda": {
        type: "REQUEST",
        name: "request_16 Redirect 2",
path: "request_16 Redirect 2",
pathFormatted: "req_request-16-redi-74dda",
stats: {
    "name": "request_16 Redirect 2",
    "numberOfRequests": {
        "total": "185",
        "ok": "185",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "850",
        "ok": "850",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "336",
        "ok": "336",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "208",
        "ok": "208",
        "ko": "-"
    },
    "percentiles1": {
        "total": "305",
        "ok": "305",
        "ko": "-"
    },
    "percentiles2": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "percentiles3": {
        "total": "756",
        "ok": "756",
        "ko": "-"
    },
    "percentiles4": {
        "total": "825",
        "ok": "825",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 181,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.022",
        "ok": "1.022",
        "ko": "-"
    }
}
    },"req_request-16-redi-6b920": {
        type: "REQUEST",
        name: "request_16 Redirect 3",
path: "request_16 Redirect 3",
pathFormatted: "req_request-16-redi-6b920",
stats: {
    "name": "request_16 Redirect 3",
    "numberOfRequests": {
        "total": "185",
        "ok": "185",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 185,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.022",
        "ok": "1.022",
        "ko": "-"
    }
}
    },"req_request-19-10d85": {
        type: "REQUEST",
        name: "request_19",
path: "request_19",
pathFormatted: "req_request-19-10d85",
stats: {
    "name": "request_19",
    "numberOfRequests": {
        "total": "185",
        "ok": "172",
        "ko": "13"
    },
    "minResponseTime": {
        "total": "44",
        "ok": "44",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "34230",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "9057",
        "ok": "5207",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "16353",
        "ok": "8755",
        "ko": "1"
    },
    "percentiles1": {
        "total": "1997",
        "ok": "1791",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "5149",
        "ok": "4284",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "33151",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "33963",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 49,
    "percentage": 26
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 107,
    "percentage": 58
},
    "group4": {
    "name": "failed",
    "count": 13,
    "percentage": 7
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.022",
        "ok": "0.95",
        "ko": "0.072"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "185",
        "ok": "185",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "percentiles4": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 185,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.022",
        "ok": "1.022",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "185",
        "ok": "185",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "percentiles4": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 185,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.022",
        "ok": "1.022",
        "ko": "-"
    }
}
    },"req_request-20-6804b": {
        type: "REQUEST",
        name: "request_20",
path: "request_20",
pathFormatted: "req_request-20-6804b",
stats: {
    "name": "request_20",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2848",
        "ok": "2848",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "829",
        "ok": "829",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "693",
        "ok": "693",
        "ko": "-"
    },
    "percentiles1": {
        "total": "626",
        "ok": "626",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1162",
        "ok": "1162",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2346",
        "ok": "2346",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2512",
        "ok": "2512",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 119,
    "percentage": 60
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 33,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 48,
    "percentage": 24
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-22-8ecb1": {
        type: "REQUEST",
        name: "request_22",
path: "request_22",
pathFormatted: "req_request-22-8ecb1",
stats: {
    "name": "request_22",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10911",
        "ok": "10911",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1348",
        "ok": "1348",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1319",
        "ok": "1319",
        "ko": "-"
    },
    "percentiles1": {
        "total": "996",
        "ok": "996",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1981",
        "ok": "1981",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3315",
        "ok": "3315",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4677",
        "ok": "4677",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 82,
    "percentage": 41
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 32,
    "percentage": 16
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 86,
    "percentage": 43
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-21-be4cb": {
        type: "REQUEST",
        name: "request_21",
path: "request_21",
pathFormatted: "req_request-21-be4cb",
stats: {
    "name": "request_21",
    "numberOfRequests": {
        "total": "200",
        "ok": "198",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "34634",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "3922",
        "ok": "3356",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "8624",
        "ok": "6561",
        "ko": "1"
    },
    "percentiles1": {
        "total": "1340",
        "ok": "1326",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "3236",
        "ok": "3106",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "16887",
        "ok": "16276",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "34888",
        "ok": "34000",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 60,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 31,
    "percentage": 16
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 107,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "count": 2,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.094",
        "ko": "0.011"
    }
}
    },"req_request-23-98f5d": {
        type: "REQUEST",
        name: "request_23",
path: "request_23",
pathFormatted: "req_request-23-98f5d",
stats: {
    "name": "request_23",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3040",
        "ok": "3040",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "865",
        "ok": "865",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "866",
        "ok": "866",
        "ko": "-"
    },
    "percentiles1": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1623",
        "ok": "1623",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2535",
        "ok": "2535",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2993",
        "ok": "2993",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 122,
    "percentage": 61
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 15,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 63,
    "percentage": 32
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-24-dd0c9": {
        type: "REQUEST",
        name: "request_24",
path: "request_24",
pathFormatted: "req_request-24-dd0c9",
stats: {
    "name": "request_24",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10686",
        "ok": "10686",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1429",
        "ok": "1429",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1750",
        "ok": "1750",
        "ko": "-"
    },
    "percentiles1": {
        "total": "654",
        "ok": "654",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2067",
        "ok": "2067",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4544",
        "ok": "4544",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7376",
        "ok": "7376",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 103,
    "percentage": 52
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 12,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 85,
    "percentage": 43
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-25-20ee6": {
        type: "REQUEST",
        name: "request_25",
path: "request_25",
pathFormatted: "req_request-25-20ee6",
stats: {
    "name": "request_25",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-26-18b3c": {
        type: "REQUEST",
        name: "request_26",
path: "request_26",
pathFormatted: "req_request-26-18b3c",
stats: {
    "name": "request_26",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-27-649b0": {
        type: "REQUEST",
        name: "request_27",
path: "request_27",
pathFormatted: "req_request-27-649b0",
stats: {
    "name": "request_27",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "percentiles3": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles4": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-28-297b8": {
        type: "REQUEST",
        name: "request_28",
path: "request_28",
pathFormatted: "req_request-28-297b8",
stats: {
    "name": "request_28",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "718",
        "ok": "718",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "144",
        "ok": "144",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "159",
        "ok": "159",
        "ko": "-"
    },
    "percentiles1": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles2": {
        "total": "216",
        "ok": "216",
        "ko": "-"
    },
    "percentiles3": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles4": {
        "total": "579",
        "ok": "579",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-29-6a22e": {
        type: "REQUEST",
        name: "request_29",
path: "request_29",
pathFormatted: "req_request-29-6a22e",
stats: {
    "name": "request_29",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "34009",
        "ok": "34009",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1333",
        "ok": "1333",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3409",
        "ok": "3409",
        "ko": "-"
    },
    "percentiles1": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1377",
        "ok": "1377",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3507",
        "ok": "3507",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17613",
        "ok": "17613",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 133,
    "percentage": 67
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 57,
    "percentage": 28
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-30-b7b42": {
        type: "REQUEST",
        name: "request_30",
path: "request_30",
pathFormatted: "req_request-30-b7b42",
stats: {
    "name": "request_30",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2867",
        "ok": "2867",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "608",
        "ok": "608",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "771",
        "ok": "771",
        "ko": "-"
    },
    "percentiles1": {
        "total": "243",
        "ok": "243",
        "ko": "-"
    },
    "percentiles2": {
        "total": "784",
        "ok": "784",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2361",
        "ok": "2361",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2470",
        "ok": "2470",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 150,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 36,
    "percentage": 18
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-32-84a21": {
        type: "REQUEST",
        name: "request_32",
path: "request_32",
pathFormatted: "req_request-32-84a21",
stats: {
    "name": "request_32",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10327",
        "ok": "10327",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "967",
        "ok": "967",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1343",
        "ok": "1343",
        "ko": "-"
    },
    "percentiles1": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1256",
        "ok": "1256",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3610",
        "ok": "3610",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6071",
        "ok": "6071",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 132,
    "percentage": 66
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 52,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-31-261d3": {
        type: "REQUEST",
        name: "request_31",
path: "request_31",
pathFormatted: "req_request-31-261d3",
stats: {
    "name": "request_31",
    "numberOfRequests": {
        "total": "200",
        "ok": "199",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "33768",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "2180",
        "ok": "1889",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "5627",
        "ok": "3865",
        "ko": "0"
    },
    "percentiles1": {
        "total": "441",
        "ok": "438",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "1743",
        "ok": "1738",
        "ko": "60000"
    },
    "percentiles3": {
        "total": "7766",
        "ok": "7565",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "18666",
        "ok": "18091",
        "ko": "60000"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 115,
    "percentage": 57
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 73,
    "percentage": 37
},
    "group4": {
    "name": "failed",
    "count": 1,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.099",
        "ko": "0.006"
    }
}
    },"req_request-33-6bb92": {
        type: "REQUEST",
        name: "request_33",
path: "request_33",
pathFormatted: "req_request-33-6bb92",
stats: {
    "name": "request_33",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "552",
        "ok": "552",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "117",
        "ok": "117",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "139",
        "ok": "139",
        "ko": "-"
    },
    "percentiles1": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles2": {
        "total": "141",
        "ok": "141",
        "ko": "-"
    },
    "percentiles3": {
        "total": "458",
        "ok": "458",
        "ko": "-"
    },
    "percentiles4": {
        "total": "522",
        "ok": "522",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 200,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    },"req_request-34-d9757": {
        type: "REQUEST",
        name: "request_34",
path: "request_34",
pathFormatted: "req_request-34-d9757",
stats: {
    "name": "request_34",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "34132",
        "ok": "34132",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1388",
        "ok": "1388",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3184",
        "ok": "3184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "348",
        "ok": "348",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1299",
        "ok": "1299",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4428",
        "ok": "4428",
        "ko": "-"
    },
    "percentiles4": {
        "total": "10422",
        "ok": "10422",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 133,
    "percentage": 67
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 15,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 52,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.105",
        "ok": "1.105",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
